package com.example.reactivepostgres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactivePostgresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactivePostgresApplication.class, args);
	}

}
